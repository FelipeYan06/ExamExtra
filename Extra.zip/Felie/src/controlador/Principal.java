
package controlador;

/**
 *
 * @author Felipe Yan
 */
public class Principal {
    public static void author64762(){
        System.out.println("Nombre: Felipe Yan Santos");
        System.out.println("Matricula: 64762");
        System.out.println("Correo: al64762@uacam.com");
        System.out.println("Hobbie: Jugar Videojuegos, ver peliculas");
    } 
    
    public static void main(String[] args) {
        author64762();
    }
    
}
